import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm'

const supabaseUrl = 'https://nkgqbkgkpopbgmjcifqz.supabase.co'
const supabaseKey = 'sb_publishable_VupricqCBObG38Gw_DuRvg_xJgCwxua'

export const supabase = createClient(supabaseUrl, supabaseKey)